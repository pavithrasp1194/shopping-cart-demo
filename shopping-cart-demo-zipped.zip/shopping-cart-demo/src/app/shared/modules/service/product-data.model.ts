export interface IProductResponse {
  partId: number;
  title: string;
  image2: string;
  description: string;
  priceValue: string | number;
}
