import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { IProductResponse } from '../service/product-data.model';

@Injectable({
  providedIn: 'root'
})
export class ProductDataService {
  private serverBaseUrl = 'https://shopping-cart-demo-api.herokuapp.com';
  private productPath = 'products';
  public cartList = [];

  constructor(private http: HttpClient) { }

  // fetch product list from API
  public getProducts() {
    const url = `${this.serverBaseUrl}/${this.productPath}`;
    return this.http.get<IProductResponse[]>(url);
  }

  // insert selected product into carList
  public addToCart(product: IProductResponse) {
    if (!this.cartList.find(item => item.partId === product.partId)) {
      Object.assign(product, { quantity: 1 });
      this.cartList.push(product);
    } else {
      const currentProduct = this.cartList.find(item => item.partId === product.partId);
      Object.assign(currentProduct, { quantity: currentProduct.quantity + 1 });
    }
  }

}
