import { Component, OnInit, Injectable } from '@angular/core';
import { ProductDataService } from 'src/app/shared/modules/service/product-list.service';
import { IProductResponse } from 'src/app/shared/modules/service/product-data.model';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable()
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  public productList$: Observable<IProductResponse[]>;

  constructor(private productService: ProductDataService) {
  }

  ngOnInit() {
    this.productList$ = this.productService.getProducts().pipe(map(
      products => {
        return products.map(prod =>
          Object.assign(prod, { priceValue: Number(String(prod.priceValue).replace(',', '')) }));
      }
    ));
  }
  public addToCart(product: IProductResponse) {
    this.productService.addToCart(product);
  }

}
