import { Component, OnInit, Input } from '@angular/core';
import { ProductDataService } from 'src/app/shared/modules/service/product-list.service';

@Component({
  selector: 'app-cartsummary',
  templateUrl: './cartsummary.component.html',
  styleUrls: ['./cartsummary.component.scss']
})
export class CartsummaryComponent implements OnInit {
  public cartList = [];
  public sum = 0;
  constructor(private productService: ProductDataService) {
    this.cartList = productService.cartList;
  }

  ngOnInit() {
    for (const product of this.cartList) {
      this.sum = this.sum + (product.priceValue * product.quantity);
    }
  }
  public increaseQuantity(product) {
    product.quantity = product.quantity + 1;
    this.sum = this.sum + product.priceValue;

  }
  public decreaseQuantity(product) {
    product.quantity = product.quantity - 1;
    this.sum = this.sum - product.priceValue;
    if (product.quantity <= 0) {
      this.removeItem(product);
    }
  }

  public removeItem(product) {
    this.cartList = this.cartList.filter(item => item.partId !== product.partId);
    this.productService.cartList = this.cartList;
    this.totalAmount();
  }

  public totalAmount() {
    this.sum = 0;
    for (const product of this.cartList) {
      this.sum = this.sum + (product.priceValue * product.quantity);
    }
    return this.sum;
  }

}
